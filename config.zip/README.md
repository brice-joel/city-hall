# 🏛️ CityHall GED — Gestion Électronique de Documents & État Civil Municipal

<p align="center">
  <img src="https://img.shields.io/badge/Laravel-12.x-FF2D20?style=for-the-badge&logo=laravel&logoColor=white" alt="Laravel 12" />
  <img src="https://img.shields.io/badge/React-18.x-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React 18" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-v4.0-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Tailwind CSS v4" />
  <img src="https://img.shields.io/badge/Inertia.js-2.0-9553E9?style=for-the-badge&logo=inertia&logoColor=white" alt="Inertia.js" />
</p>

## 📋 Présentation du Projet

**CityHall GED** est une solution logicielle moderne destinée aux administrations municipales et mairies. Elle simplifie, sécurise et accélère le traitement de la paperasse administrative, l'archivage électronique et la rédaction des actes d'état civil.

Pour ce **MVP (Minimum Viable Product)**, la solution permet la prise en main immédiate et directe du module **Création d'Actes de Naissance** sans authentification préalable, tout en conservant les contrôleurs et pages d'authentification pour les évolutions futures.

---

## ✨ Fonctionnalités Clés (MVP)

- 🏠 **Page d'Accueil (`Index`)** : Présentation dynamique de la suite logicielle municipale (Actes de naissance, mariage, décès, et GED / archivage).
- 👶 **Module Acte de Naissance (Opérationnel)** :
  - Formulaire de rédaction officielle (Enfant, Filiation, Déclarant, Officier d'État Civil instrumentaire).
  - Aperçu officiel en temps réel du document papier conforme.
  - Registre consultable avec filtres de recherche instantanée.
  - Impression directe d'extraits d'actes d'état civil.
- 🎨 **Interface & Thème Apaisant (`AppLayout`)** :
  - Design professionnel avec palette adoucissante anti-fatigue visuelle (nuances Slate, Soft Teal & Indigo).
  - Sidebar responsive réductible avec icônes intuitives (`lucide-react`).
  - Header complet avec barre de recherche universelle et indicateur de session de la mairie.
- ⚡ **Migration Tailwind CSS v4** :
  - Intégration native Vite via `@tailwindcss/vite`.
  - Suppression de PostCSS et des dépendances héritées de Tailwind v3.

---

## 🛠️ Stack Technique

- **Backend** : PHP 8 border, Laravel 12 framework
- **Frontend** : React 18, TypeScript, Inertia.js 2.0
- **Styles** : Tailwind CSS v4, Lucide React Icons
- **Bundler** : Vite avec plugin natif `@tailwindcss/vite`

---

## 📂 Structure du Code Frontend (`resources/js/`)

```bash
resources/js/
├── Components/
│   ├── AuthContainer.tsx     # Conteneur des pages d'authentification (conservées)
│   └── ...                   # Composants réutilisables UI
├── Layouts/
│   └── AppLayout.tsx         # Layout principal municipal (Header, Sidebar, Responsive Main)
├── Pages/
│   ├── Index.tsx             # Dashboard principal de la mairie
│   ├── BirthCertificate/
│   │   ├── Index.tsx         # Registre & consultation des actes de naissance
│   │   └── Create.tsx        # Formulaire de rédaction et aperçu en temps réel
│   └── Auth/                 # Pages d'authentification (Login, Register, etc.)
├── types/
│   └── index.d.ts            # Interfaces TypeScript (BirthCertificate, PageProps, User)
└── css/
    └── app.css               # Configuration Tailwind v4 (@import "tailwindcss";)
```

---

## 🚀 Installation & Lancement Rapide

### Préréquis
- PHP >= 8.2 & Composer
- Node.js >= 18.x & npm

### 1. Cloner & Installer les Dépendances
```bash
# Dépendances PHP
composer install

# Dépendances JavaScript
npm install
```

### 2. Configuration de l'Environnement
```bash
cp .env.example .env
php artisan key:generate
```

### 3. Lancer le Serveur de Développement
Dans deux terminaux séparés :

**Terminal 1 (Serveur Laravel) :**
```bash
php artisan serve
```

**Terminal 2 (Vite Asset Bundler) :**
```bash
npm run dev
```

Rendez-vous ensuite sur `http://localhost:8000` ou `http://127.0.0.1:8000` !

---

## 🔒 Conservation des Composants Auth

Les contrôleurs `app/Http/Controllers/Auth/*` ainsi que les vues `resources/js/Pages/Auth/*` restent préservés et intégrés au projet pour l'activation ultérieure des rôles d'accès et du contrôle de sécurité.

---

## 📄 Licence
Ce projet est développé pour la gestion administrative municipale.
