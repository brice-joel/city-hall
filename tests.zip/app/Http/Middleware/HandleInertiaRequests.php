<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that is loaded on the first page visit.
     *
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determine the current asset version.
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Define the props that are shared by default.
     *
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        return [
            ...parent::share($request),
            'auth' => [
                'user' => $request->user(),
            ],
            'flash' => [
                'success' => fn () => $request->session()->get('success') ?? (is_array($request->session()->get('flash')) ? ($request->session()->get('flash')['success'] ?? null) : null),
                'error' => fn () => $request->session()->get('error') ?? (is_array($request->session()->get('flash')) ? ($request->session()->get('flash')['error'] ?? null) : null),
            ],
        ];
    }
}
